package Task;

public class Person {

	// Класът Person репрезентиращ човек да има следните
	// Полета:
	// name - име
	// age - години
	// isMale - поле, показващо пола
	private String name; // за да се достъпват само в класа
	private int age;
	private boolean isMale;

	private boolean dataIsValid; // създавам такава променлива, за да мога да
									// проверявам в подкласовете за валидността
									// на данните в основния клас

	// Коструктори:
	// Единствен конструктор, с параметри за всичките полета на класа
	protected Person(String name, int age, boolean isMale) { // за да го
																// извикваме в
																// подкласовете
																// и в демото
		if (name != null) { // проверявам първо стойността на name не е null,
							// защото ако проверявам това в долния if заедно с
							// другите проверки ще трябва да се опитам да
							// достъпя name, за да проверя дали не е празен
							// стринг и ако стойността на name e null ще изгърми
							// nullPointerException
			if (name.trim().length() != 0 && age >= 0 && age <= 120) { // ако
																		// стойността
																		// на
																		// name
																		// не е
																		// null
																		// правя
																		// другите
																		// проверки
				this.name = name;
				this.age = age;
				this.isMale = isMale;
				dataIsValid = true;
			} else {
				System.out.println("\nUnvalid personal data is inputted.");
			}
		} else {
			System.out.println("\nUnvalid personal data is inputted.");

		}

	}

	// Метод:
	// Метод showPersonInfo, който показва информация за човека (изписва
	// на конзолата стойността на всичките му полета по подходящ начин)
	protected void showInfo() { // -//-//
		if (dataIsValid) { // с dataIsValid проверявам дали има стойност за name
							// и age и дали те са валидни
			System.out.println("\nPersonal Information: ");
			System.out.println("name: " + this.name);
			System.out.println("age: " + this.age);
			System.out.println("sex: " + (isMale ? "male" : "female"));
		} else {
			System.out.println("\nThe personal data about this person is not valid. ");
		}
	}

	protected String getName() { // за достъпване на private характеристиките
		return this.name;
	}

	protected int getAge() {
		return this.age;
	}

	protected boolean getDataIsValid() {
		return this.dataIsValid;
	}
}
