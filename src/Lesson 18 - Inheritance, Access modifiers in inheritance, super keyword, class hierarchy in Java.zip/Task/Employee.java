package Task;

public class Employee extends Person {

	// Класът Employee да наследява Person и да дефинира:
	// Полета:
	// daySalary показва дневната заплата на работника
	private double daySalary;
	private double workHours;

	private boolean dataIsValid; // за да проверявам и тези
									// клас-характеристиките

	// Конструктор които инициализира всичките му полета (собствени
	// и наследени)
	protected Employee(String name, int age, boolean isMale, double daySalary, double workHours) {
		super(name, age, isMale);
		if (daySalary >= 0) {
			this.daySalary = daySalary;
		} else {
			System.out.println("\nUnvalid daily salary is inputted.");
		}
		if (workHours >= 0 && workHours <= 12) {
			this.workHours = workHours;
		} else {
			System.out.println("\nUnvalid hours of work are inputted.");
		}
		if (daySalary >= 0 && workHours >= 0 && workHours <= 12) {
			this.dataIsValid = true;
		}
	}

	// Методи:
	// В случай че на работник се наложи да работи извън работно
	// време, на него му се дължи допълнителна сума пари (overtime) за
	// часовете които е работил. Сумата се пресмята по следния начин: ако
	// работника, няма навършени 18 години, дължимата сума е 0. В
	// противен случай, за всеки отработен час, на работника се заплаща
	// сумата която получава на час (зависи от дневната заплата) умножена
	// по 1,5.
	// метод calculateOvertime(double hours) който пресмята и връща стойността
	// на сумата която му се дължи при работа извън работно време
	protected double calculateOvertime(double hours) {
		if (super.getAge() >= 18 && this.dataIsValid == true) {
			return hours * ((this.daySalary / this.workHours) * 1.5);
		} else
			return 0;
	}

	// метод showEmployeeInfo(), който показва информация за човека, както и
	// информация за дневната му заплата
	@Override
	protected void showInfo() {
		if (super.getDataIsValid()) { // super.showInfo си проверява валидността
										// на данните, но тук го използвам, за
										// да може ако данните не са валидни да
										// изпише "The personal data about this
										// EMPLOYEE is not valid.", а не да
										// извика super.showInfo, който ще
										// провери отново, но ако не са ще
										// изпише "The personal data about this
										// PERSON is not valid."
			super.showInfo(); // ако личните данни са валидни ще ги изпише и
								// след това ще проверява стойността на
								// характеристиките, които само класът Employee
								// притежава.
			if (daySalary >= 0) {
				System.out.println("daily salary: " + this.daySalary);
			} else {
				System.out.println("This employee doesn't have a valid daily salary.");
			}
			if (workHours >= 0) {
				System.out.println("hours of work: " + this.workHours);
			} else {
				System.out.println("This employee doesn't have valid hours of work.");
			}
		} else {
			System.out.println("\nThe personal data about this employee is not valid.");
		}
	}

}
