package Task;

public class Student extends Person {

	// Класът Student наследяващ Person, репрезентиращ ученик да има
	// Полета:
	// score - показва оценката на ученика (число между 2 и 6, не е
	// задължително да е цяло)

	private double score;

	// Единствен конструктор:
	// Student(String name, int age, boolean isMale, double score)
	// задаващ стойности и на наследените полета
	protected Student(String name, int age, boolean isMale, double score) {
		super(name, age, isMale);
		if (score >= 2 && score <= 6) {
			this.score = score;
		} else {
			System.out.println("\nUnvalid score is inputted.");
		}
	}

	// Метод showStudentInfo() който показва информация за човека и
	// информация за оценката му (чрез надписи на екрана)
	@Override
	protected void showInfo() {
		if (super.getDataIsValid()) {// super.showInfo си проверява валидността
										// на данните, но тук го използвам, за
										// да може ако данните не са валидни да
										// изпише "The personal data about this
										// STUDENT is not valid.", а не да
										// извика super.showInfo, който ще
										// провери отново, но ако не са ще
										// изпише "The personal data about this
										// PERSON is not valid."
			super.showInfo(); // ако личните данни са валидни ще ги изпише след
								// това ще проверява стойността на
								// характеристиките, които само класът Student
								// притежава.
			if (score >= 2 && score <= 6) {
				System.out.println("score: " + this.score);
			} else {
				System.out.println("This student doesn't have a valid score.");
			}
		} else {
			System.out.println("\nThe personal data about this student is not valid.");
		}
	}

}
